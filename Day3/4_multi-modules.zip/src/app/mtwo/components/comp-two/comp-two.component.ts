import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comp-two',
  template: `
    <h1 class="text-success">Hello from Component Two - Module Two</h1>
    <app-hello></app-hello>
    <app-scomp></app-scomp>
  `,
  styles: [
  ]
})
export class CompTwoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
