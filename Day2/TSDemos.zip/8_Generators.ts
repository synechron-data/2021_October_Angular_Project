// function* idGenerator() {
//     // console.log("Id Generator Called....");
//     var id = 0;
//     while (true) {
//         yield id++;
//     }
// }

// var seq = idGenerator();

// console.log(seq.next());
// console.log(seq.next());
// console.log(seq.next());
// console.log(seq.next());

// ---------------------------------------------------------------

// class GQueue<T> {
//     private _data: T[] = [];

//     push(d: T) {
//         this._data.push(d);
//     }

//     pop(): T | undefined {
//         return this._data.shift();
//     }

//     *[Symbol.iterator]() {
//         for (let i = 0; i < this._data.length; i++) {
//             yield this._data[i];
//         }
//     }
// }

class GQueue<T> {
    private _data: T[] = [];

    push(d: T) {
        this._data.push(d);
    }

    pop(): T | undefined {
        return this._data.shift();
    }

    *[Symbol.iterator]() {
        yield* this._data;
    }
}

var numQ = new GQueue<number>();
numQ.push(10);
numQ.push(20);
numQ.push(30);

for (const item of numQ) {
    console.log(item);
}