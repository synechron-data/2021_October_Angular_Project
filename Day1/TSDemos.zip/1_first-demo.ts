console.log("Hello from First Demo");

class Program {
    static main(arg: string): void {
        console.log(`Hello, ${arg}`);
    }
}

Program.main("Synechron");