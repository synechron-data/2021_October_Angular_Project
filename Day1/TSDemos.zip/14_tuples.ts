// var myArray = [10, 20, 30, "Manish", true];

// Typeguard Array
var myArray: (string | number)[];
myArray = ["Manish", 1];
myArray = ["Abhijeet", "Pune"];
myArray = [10, 20, 30, 40, 50];
myArray = [1, "Manish"];
myArray = [1, "Abhijeet", "Pune", 411038];

// Tuple - Stores a fixed collection of values of same or varied types, maintaining the sequence
let dataRow: [number, string];
dataRow = [1, "Manish"];
// dataRow = ["Manish", 1];
// dataRow = ["Abhijeet", "Pune"];
// dataRow = [10, 20, 30, 40, 50];
// dataRow = [1, "Abhijeet", "Pune", 411038];