// Global Scope
// Local Scope (Function Scope)
// Block Scope (Using let and const keyword)

// Global Variable
// var i = 20;

// // function test() {
// //     var i = 100;
// //     console.log("Inside, Function: ", i);
// // }

// function test() {
//     // var does not support Block Scoping
//     if (true) {
//         var i = 100;
//         console.log("Inside, if block: ", i);
//     }
//     console.log("Inside, Function: ", i);
// }

// test();
// console.log("Outside, Function: ", i);

// var i = 20;
// var i = 30;
// console.log(i);

// Support Hoisting - Moving Declarations to the top
// a = "Hello";
// console.log(a);
// var a;

// Using Var keyword, you will get, either Global or Function Scoping
// var does not support Block Scoping

// var i = 100;
// console.log("Before, i is", i);

// // for (var i = 0; i < 5; i++) {
// //     console.log("Inside Loop, i is", i);
// // }

// for (var _i = 0; _i < 5; _i++) {
//     console.log("Inside Loop, _i is", _i);
// }

// console.log("After, i is", i);

// --------------------------------------------------------------------------------
// let i = 20;
// let i = 30;             // Compile Time Error: Cannot redeclare block-scoped variable 'i'
// console.log(i);

// Does not Support Hoisting
// a = "Hello";
// console.log(a);
// let a;

var i = 100;
console.log("Before, i is", i);

for (let i = 0; i < 5; i++) {
    console.log("Inside Loop, i is", i);
}

console.log("After, i is", i);