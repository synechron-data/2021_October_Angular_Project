import { Component, EventEmitter, Input, NgZone, OnInit, Output } from '@angular/core';

@Component({
  selector: 'counter',
  templateUrl: './counter.component.html',
  styles: [
  ]
})
export class CounterComponent implements OnInit {
  @Input() interval: number;
  @Output() onMax: EventEmitter<boolean>;

  flag: boolean;
  count: number;

  clickCount: number;

  constructor(private ngZone: NgZone) {
    this.interval = 1;
    this.flag = false;
    this.count = 0;
    this.clickCount = 0;
    this.onMax=new EventEmitter<boolean>();
  }

  ngOnInit(): void {
  }

  manageClickCount() {
    this.clickCount += 1;
    if (this.clickCount > 9) {
      this.flag = true;
      this.onMax.emit(this.flag);
    }
  }

  inc() {
    // this.ngZone.runOutsideAngular(() => { this.manageClickCount(); });
    this.manageClickCount();
    this.count += this.interval;
  }

  dec() {
    this.manageClickCount();
    this.count -= this.interval;
  }

  reset() {
    this.flag = false;
    this.count = 0;
    this.clickCount = 0;
    this.onMax.emit(this.flag);
  }
}
