import { Component, OnInit } from '@angular/core';
import { BehaviorSubject, Observable, Observer, ReplaySubject, Subject, Subscription, of, concat, EMPTY } from 'rxjs';
import { delay, filter, map, reduce, startWith } from 'rxjs/operators';

@Component({
  selector: 'app-root',
  templateUrl: './root.component.html'
})
export class RootComponent implements OnInit {
  obSub?: Subscription;

  ngOnInit(): void {
    // this.getPromise();
    // this.getObservable();

    // this.getPromise().then(data => {
    //   console.log(`Promise Output - ${data}`);
    // }).catch(err => {
    //   console.error(`Promise Error - ${err}`);
    // });

    // this.obSub = this.getObservable().subscribe(data => {
    //   console.log(`Observable Output - ${data}`);
    // }, err => {
    //   console.error(`Observable Error - ${err}`);
    // });

    // setTimeout(() => {
    //   this.obSub?.unsubscribe();
    // }, 9000);

    // // ------------------------------------- Observables are single-cast
    // var ob = this.getObservable();

    // ob.subscribe(data => {
    //   console.log(`Subscriber 1, Output - ${data}`);
    // }, err => {
    //   console.error(`Subscriber 1, Error - ${err}`);
    // });

    // ob.subscribe(data => {
    //   console.log(`Subscriber 2, Output - ${data}`);
    // }, err => {
    //   console.error(`Subscriber 2, Error - ${err}`);
    // });

    // ------------------------------------- Subjects as multi-cast observable
    // var subject = this.getSubject();

    // subject.subscribe(data => {
    //   console.log(`Subscriber 1, Output - ${data}`);
    // }, err => {
    //   console.error(`Subscriber 1, Error - ${err}`);
    // });

    // subject.subscribe(data => {
    //   console.log(`Subscriber 2, Output - ${data}`);
    // }, err => {
    //   console.error(`Subscriber 2, Error - ${err}`);
    // });

    // ------------------------------------- Subjects as observables
    // var observable = this.getSubjectAsObservable();

    // observable.subscribe(data => {
    //   console.log(`Subscriber 1, Output - ${data}`);
    // }, err => {
    //   console.error(`Subscriber 1, Error - ${err}`);
    // });

    // observable.subscribe(data => {
    //   console.log(`Subscriber 2, Output - ${data}`);
    // }, err => {
    //   console.error(`Subscriber 2, Error - ${err}`);
    // });

    // ------------------------------------- Subject Types
    // // var subject = this.getSubjectA();
    // // var subject = this.getSubjectB();
    // var subject = this.getSubjectC();

    // var s2: Subscription;

    // var s1 = subject.subscribe(data => {
    //   console.log(`Subscriber 1, Output - ${data}`);
    // });

    // setTimeout(() => {
    //   console.log("\nAfter 6 secs, S2 subscribed: ")
    //   s2 = subject.subscribe(data => {
    //     console.log(`Subscriber 2, Output - ${data}`);
    //   });
    // }, 6100);

    // setTimeout(() => {
    //   s1.unsubscribe();
    //   s2.unsubscribe();
    // }, 11000);

    //  ------------------------------------- Observable Operators & Methods
    let numObservable = of(10, 20, 30, 40, 53, 60, 71, 85, 99);
    // numObservable.subscribe(n => console.log(n));

    // let evenObservables = numObservable.pipe(
    //   filter(n => n % 2 === 0),
    //   map(n => n * 10),
    //   reduce((acc, n) => acc + n)
    // );

    // evenObservables.subscribe(n => console.log(n));

    // numObservable.pipe(
    //   filter(n => n % 2 === 0),
    //   map(n => n * 10),
    //   reduce((acc, n) => acc + n)
    // ).subscribe(n => console.log(n));

    // let obs1 = of(10, 20, 30);
    // let obs2 = of(40, 50, 60);

    // concat(obs1, obs2).subscribe(n => console.log(n));

    // concat(
    //   this.delayMessage('Get Ready'),
    //   this.delayMessage(5),
    //   this.delayMessage(4),
    //   this.delayMessage(3),
    //   this.delayMessage(2),
    //   this.delayMessage(1),
    //   this.delayMessage("Go Now"),
    // ).subscribe(m => console.log(m));
  }

  delayMessage(message: any, delayTime=1000){
    return EMPTY.pipe(startWith(message), delay(delayTime));
  }

  getSubjectC(): ReplaySubject<number> {
    let s = new ReplaySubject<number>();
    let count = 1;
    setInterval(function () {
      s.next(count++);
    }, 2000);

    return s;
  }

  getSubjectB(): BehaviorSubject<number> {
    let s = new BehaviorSubject<number>(0);     // 0 is the initial Value
    let count = 1;
    setInterval(function () {
      s.next(count++);
    }, 2000);

    return s;
  }

  getSubjectA(): Subject<number> {
    let s = new Subject<number>();
    let count = 1;
    setInterval(function () {
      s.next(count++);
    }, 2000);

    return s;
  }

  getSubjectAsObservable(): Observable<number> {
    let s = new Subject<number>();

    setInterval(function () {
      s.next(Math.random());
    }, 4000);

    return s.asObservable();
  }

  getSubject(): Subject<number> {
    let s = new Subject<number>();

    setInterval(function () {
      s.next(Math.random());
    }, 4000);

    return s;
  }

  getObservable(): Observable<number> {
    return new Observable((ob: Observer<number>) => {
      // Any Async Code
      setInterval(function () {
        // console.log("Observable - Set Interval Executed...");
        ob.next(Math.random());
      }, 4000);
    })
  }

  getPromise(): Promise<number> {
    return new Promise((resolve, reject) => {
      // Any Async Code
      setInterval(function () {
        // console.log("Promise - Set Interval Executed...");
        resolve(Math.random());
      }, 4000);
    })
  }
}
