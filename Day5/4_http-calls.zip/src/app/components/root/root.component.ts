// import { HttpClient, HttpErrorResponse } from '@angular/common/http';
// import { Component, OnDestroy, OnInit } from '@angular/core';
// import { Subscription } from 'rxjs';
// import { Post } from 'src/app/models/post.model';

// @Component({
//     selector: 'app-root',
//     templateUrl: 'root.component.html'
// })
// export class RootComponent implements OnInit, OnDestroy {
//     url: string;
//     message: string;
//     posts?: Array<Post>;
//     get_sub?: Subscription;

//     constructor(private httpClient: HttpClient) {
//         this.url = "https://jsonplaceholder.typicode.com/posts";
//         this.message = "Loading Data, please wait...";
//     }

//     ngOnInit() {
//         this.get_sub = this.httpClient.get<Array<Post>>(this.url).subscribe(resData => {
//             this.posts = [...resData];
//             this.message = "";
//         }, (err: HttpErrorResponse) => {
//             this.message = err.message;
//         });
//     }

//     ngOnDestroy(): void {
//         this.get_sub?.unsubscribe();
//     }
// }

//---------------------------------------------------------

// import { HttpClient, HttpErrorResponse } from '@angular/common/http';
// import { Component, OnDestroy, OnInit } from '@angular/core';
// import { Subscription } from 'rxjs';
// import { Post } from 'src/app/models/post.model';
// import { PostsService } from 'src/app/services/posts.service';

// @Component({
//     selector: 'app-root',
//     templateUrl: 'root.component.html',
//     providers: [PostsService]
// })

// export class RootComponent implements OnInit, OnDestroy {
//     message: string;
//     posts?: Array<Post>;
//     get_sub?: Subscription;

//     constructor(private postsService: PostsService) {
//         this.message = "Loading Data, please wait...";
//     }

//     ngOnInit() {
//         this.get_sub = this.postsService.getAllPosts().subscribe(resData => {
//             this.posts = [...resData];
//             this.message = "";
//         }, (err: HttpErrorResponse) => {
//             this.message = err.message;
//         });
//     }

//     ngOnDestroy(): void {
//         this.get_sub?.unsubscribe();
//     }
// }

//---------------------------------------------------------

import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { Post } from 'src/app/models/post.model';
import { PostsService } from 'src/app/services/posts.service';

@Component({
    selector: 'app-root',
    templateUrl: 'root.component.html',
    // providers: [PostsService]
})

export class RootComponent implements OnInit, OnDestroy {
    message: string;
    posts?: Array<Post>;
    get_sub?: Subscription;
    ins_sub?: Subscription;
    del_sub?: Subscription;

    constructor(private postsService: PostsService) {
        this.message = "Loading Data, please wait...";
    }

    ngOnInit() {
        this.get_sub = this.postsService.getAllPosts().subscribe(resData => {
            this.posts = [...resData];
            this.message = "";
        }, (err: string) => {
            this.message = err;
        });
    }

    insertPost() {
        let newPost: Post = {
            userId: 1,
            id: 0,
            title: "Test",
            body: "Test"
        };

        this.message = "Inserting new Record, please wait...";

        this.ins_sub = this.postsService.insertPost(newPost).subscribe(resData => {
            this.posts?.unshift(resData);
            this.message = "Record Inserted Successfully";
            setTimeout(() => {
                this.message = "";
            }, 5000);
        }, (err: string) => {
            this.message = err;
        });
    }

    deletePost(id: number, e: Event) {
        e.preventDefault();

        this.message = "Deleting Record, please wait...";

        this.del_sub = this.postsService.deletePost(id).subscribe(_ => {
            if (this.posts)
                this.posts = [...this.posts.filter(p => p.id !== id)];

            this.message = "Record Deleted Successfully";
            setTimeout(() => {
                this.message = "";
            }, 5000);
        }, (err: string) => {
            this.message = err;
        });
    }

    ngOnDestroy(): void {
        this.get_sub?.unsubscribe();
    }
}